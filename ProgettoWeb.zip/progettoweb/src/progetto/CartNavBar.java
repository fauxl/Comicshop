package progetto;

import java.sql.SQLException;


public interface CartNavBar {
	

	public String Getemail(String email);
}
